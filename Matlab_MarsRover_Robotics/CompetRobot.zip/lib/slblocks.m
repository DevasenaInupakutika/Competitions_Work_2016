% Copyright 2014 - 2016 The MathWorks, Inc.
function blkStruct = slblocks

  Browser.Library = 'robot_drivers';
  Browser.Name    = 'Robot Drivers';
  blkStruct.Browser = Browser;