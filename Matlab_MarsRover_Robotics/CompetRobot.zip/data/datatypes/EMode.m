% Copyright 2014 - 2016 The MathWorks, Inc.
classdef EMode < Simulink.IntEnumType
   
    enumeration
        DISTANCE      (0)
        SPEED         (1)
    end
    
end